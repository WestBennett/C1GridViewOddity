﻿using C1.Web.Wijmo.Controls.C1GridView;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Test_Grid
{
    internal class ASP
    {
        /// <summary>
        /// Converts an ASP.NET GridView into a DataTable by inspecting its elements
        /// </summary>
        /// <param name="gridView"></param>
        /// <param name="controlTypeNamesExpectedToFind">The list of control types expected to find, IN ORDER.
        /// Pass a NULL for each column that's not expecting a control. Get this from [Type].Name attribute </param>
        /// <returns></returns>
        public static DataTable GetGridDataTable(C1GridView gridView, List<string> controlTypeNamesExpectedToFind)
        {
            try
            {
                DataTable dt = new DataTable();
                // add the columns to the datatable            
                if (gridView.HeaderRow != null)
                {

                    for (int i = 0; i < gridView.HeaderRow.Cells.Count; i++)
                    {
                        dt.Columns.Add(gridView.HeaderRow.Cells[i].Text);
                    }
                }

                //  add each of the data rows to the table
                foreach (C1GridViewRow row in gridView.Rows)
                {
                    if (!row.Visible) continue;
                    DataRow dr;
                    dr = dt.NewRow();

                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        string columnType = controlTypeNamesExpectedToFind[i];
                        //check if there's controls in this cell
                        if (row.Cells[i].Controls.Count > 0)
                        {
                            foreach (Control c in row.Cells[i].Controls)
                            {
                                //Skip the non-expected type. This prevents us from quitting out early by accident if there's multiple controls in the cell
                                if (c.GetType().Name != columnType) continue;
                                if (c.GetType() == typeof(LiteralControl))
                                {
                                    //skip, as these are useless to us
                                    continue;
                                }
                                else if (c.GetType() == typeof(DropDownList))
                                {
                                    DropDownList ddl = (DropDownList)c;
                                    dr[i] = ddl.SelectedValue;
                                    break; //Assume one control per cell as valid
                                }
                                else if (c.GetType() == typeof(TextBox))
                                {
                                    TextBox tb = (TextBox)c;
                                    dr[i] = tb.Text;
                                    break; //Assume one control per cell as valid
                                }
                                else if (c.GetType() == typeof(CheckBox))
                                {
                                    CheckBox cb = (CheckBox)c;
                                    dr[i] = cb.Checked;
                                    break; //Assume one control per cell as valid
                                }
                                else if (c.GetType() == typeof(Label))
                                {
                                    Label l = (Label)c;
                                    dr[i] = l.Text;
                                    break; //Assume one control per cell as valid
                                }
                                else if (!Core.IsNullOrEmpty(row.Cells[i].Text)) dr[i] = row.Cells[i].Text; //Just get the text if we don't know what else to do with it
                            }
                        }
                        else
                        {
                            //No controls, check for a text value in the cell
                            if (!Core.IsNullOrEmpty(row.Cells[i].Text)) dr[i] = row.Cells[i].Text;
                        }
                    }
                    dt.Rows.Add(dr);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to get grid from DataTable.", ex);
            }
        }
    }
}