﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using C1.Web.Wijmo.Controls.C1GridView;
using Test_Grid;

namespace C1GridView_Filter
{
    public partial class _Default : Page
    {

        public static List<string> gvAcceptanceColTypes = new List<string>() {
            typeof(Label).Name, typeof(Label).Name, typeof(Label).Name, typeof(Label).Name, typeof(Label).Name, typeof(Label).Name,
            typeof(Label).Name, typeof(Label).Name, typeof(Label).Name, typeof(Label).Name, typeof(Label).Name, typeof(TextBox).Name};
        private DataTable Data
        {
            get
            {
                // Retrieve the DataTable from Session
                if (Session["Data"] == null)
                {
                    // If DataTable is not present in Session, initialize it
                    Session["Data"] = GetData();
                }
                return (DataTable)Session["Data"];
            }
            set
            {
                // Store the DataTable in Session
                Session["Data"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set the DataSource for the grid on first load
                gvMain.DataSource = Data;
                gvMain.DataBind();
            }
        }
        protected void gvMain_ColumnMoving(object sender, C1GridViewColumnMoveEventArgs e)
        {
            C1BaseField dragColumn = e.Drag;
            C1BaseField dropColumn = e.Drop;
            C1GridViewDropPosition position = e.Position;
            int destIndex = e.DestIndex;

            // You can add any additional logic here if needed during column moving
        }

        public void gvMain_ColumnMoved(object sender, C1GridViewColumnMovedEventArgs e)
        {
            // Reorder the columns in the Data DataTable based on the column move operation
            // Get the current order of columns
            DataTable dataTable = Data;
            DataTable reorderedTable = new DataTable();

            // Create columns in the new order
            foreach (C1BoundField column in gvMain.Columns)
            {
                reorderedTable.Columns.Add(column.HeaderText, dataTable.Columns[column.HeaderText].DataType);
            }

            // Copy data from the old table to the new table
            foreach (DataRow row in dataTable.Rows)
            {
                DataRow newRow = reorderedTable.NewRow();
                foreach (DataColumn column in reorderedTable.Columns)
                {
                    newRow[column.ColumnName] = row[column.ColumnName];
                }
                reorderedTable.Rows.Add(newRow);
            }

            // Update the DataTable in Session
            Data = reorderedTable;

            // Rebind the data to the grid
            gvMain.DataSource = reorderedTable;
            gvMain.DataBind();
        }

        public void gvMain_Sorted(object sender, EventArgs e)
        {
            // Implement sorting logic if needed
        }

        public void gvMain_Sorting(object sender, C1GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;
            var sortDirection = e.SortDirection;

            // Sort the data based on the sort expression and direction
            DataTable dataTable = Data; // Use the DataTable from Session

            // Apply sorting
            if (dataTable != null)
            {
                string sortOrder = sortExpression + (sortDirection == C1SortDirection.Ascending ? " ASC" : " DESC");
                dataTable.DefaultView.Sort = sortOrder;
            }

            // Bind the sorted data to the grid
            gvMain.DataSource = dataTable;
            gvMain.DataBind();
        }

        public void gvMain_RowDataBound(object sender, C1GridViewRowEventArgs e)
        {
            // Implement row data binding logic if needed
        }

        public void gvMain_Filtered(object sender, EventArgs e)
        {
            // Implement post-filtering logic if needed
        }

        public void gvMain_Filtering(object sender, C1GridViewFilterEventArgs e)
        {
            DataView view = new DataView(Data); // Use the DataTable from Session

            // Build filter string
            string filterString = string.Empty;
            foreach (DictionaryEntry entry in e.Values)
            {
                string columnName = entry.Key.ToString();
                string filterValue = entry.Value.ToString();
                string filterOperator = e.Operators[columnName].ToString();

                if (!string.IsNullOrEmpty(filterValue) || filterOperator == "IsEmpty" || filterOperator == "IsNull" || filterOperator == "IsNotEmpty" || filterOperator == "IsNotNull")
                {
                    if (!string.IsNullOrEmpty(filterString))
                        filterString += " AND ";

                    switch (filterOperator)
                    {
                        case "BeginsWith":
                            filterString += $"{columnName} LIKE '{filterValue}%'";
                            break;
                        case "Contains":
                            filterString += $"{columnName} LIKE '%{filterValue}%'";
                            break;
                        case "EndsWith":
                            filterString += $"{columnName} LIKE '%{filterValue}'";
                            break;
                        case "Equals":
                            filterString += $"{columnName} = '{filterValue}'";
                            break;
                        case "GreaterThan":
                            filterString += $"{columnName} > '{filterValue}'";
                            break;
                        case "GreaterOrEqual":
                            filterString += $"{columnName} >= '{filterValue}'";
                            break;
                        case "IsEmpty":
                            filterString += $"{columnName} = ''";
                            break;
                        case "IsNull":
                            filterString += $"{columnName} IS NULL";
                            break;
                        case "LessThan":
                            filterString += $"{columnName} < '{filterValue}'";
                            break;
                        case "LessOrEqual":
                            filterString += $"{columnName} <= '{filterValue}'";
                            break;
                        case "DoesNotContain":
                            filterString += $"{columnName} NOT LIKE '%{filterValue}%'";
                            break;
                        case "NotEqual":
                            filterString += $"{columnName} <> '{filterValue}'";
                            break;
                        case "IsNotEmpty":
                            filterString += $"{columnName} <> ''";
                            break;
                        case "IsNotNull":
                            filterString += $"{columnName} IS NOT NULL";
                            break;
                    }
                }
            }

            view.RowFilter = filterString;

            gvMain.DataSource = view;
            gvMain.DataBind();
        }

        public void gvMain_RowDeleting(object sender, C1GridViewDeleteEventArgs e)
        {
            int rowIndex = e.RowIndex;

            // Check if the row index is valid
            if (rowIndex >= 0 && rowIndex < Data.Rows.Count)
            {
                // Use the unique identifier to find the row to delete
                int id = Convert.ToInt32(gvMain.DataKeys[rowIndex].Value);

                var rowToDelete = Data.AsEnumerable()
                                      .FirstOrDefault(r => r.Field<int>("IFD_BUYING_SHOW_ITEMS_ID") == id);

                if (rowToDelete != null)
                {
                    Data.Rows.Remove(rowToDelete);
                    Session["Data"] = Data;
                    gvMain.DataSource = Data;
                    gvMain.DataBind();
                }
            }
            else
            {
                // Handle the case where the row index is invalid
                // You may want to show an error message or log this event
            }
        }

        private DataTable GetData()
        {
            DataTable table = new DataTable("DummyData");

            // Adding columns
            table.Columns.Add("IFD ITEM #", typeof(string));
            table.Columns.Add("IFD_BUYING_SHOW_ITEMS_ID", typeof(int));
            table.Columns.Add("MASTER VENDOR", typeof(string));
            table.Columns.Add("ITEM VENDOR", typeof(string));
            table.Columns.Add("DESCRIPTION", typeof(string));
            table.Columns.Add("BRAND", typeof(string));
            table.Columns.Add("PACK", typeof(string));
            table.Columns.Add("MFG", typeof(string));
            table.Columns.Add("GTIN", typeof(string));
            table.Columns.Add("SUGGESTED ALLOWANCE", typeof(decimal));
            table.Columns.Add("APPROVED ALLOWANCE", typeof(decimal));

            // Adding 20 dummy data rows
            for (int i = 1; i <= 20; i++)
            {
                DataRow row = table.NewRow();
                row["IFD ITEM #"] = "Item" + i;
                row["IFD_BUYING_SHOW_ITEMS_ID"] = i;
                row["MASTER VENDOR"] = "Vendor" + i;
                row["ITEM VENDOR"] = "ItemVendor" + i;
                row["DESCRIPTION"] = "Description of Item " + i;
                row["BRAND"] = "Brand" + i;
                row["PACK"] = "Pack" + i;
                row["MFG"] = "MFG" + i;
                row["GTIN"] = "GTIN" + i;
                row["SUGGESTED ALLOWANCE"] = i * 1.1m; // Dummy decimal value
                table.Rows.Add(row);
            }
            return table;
        }

        protected void btnAcceptIFD_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
                if (!IsValid) return;
                DataTable vendorChanges = ASP.GetGridDataTable(gvMain, gvAcceptanceColTypes);
                Debug.WriteLine("");
            }
            catch (Exception ex)
            {
                throw new Exception("Error accepting.", ex);
            }
        }
    }
}
