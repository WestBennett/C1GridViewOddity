﻿using System;
using System.Data;

namespace Test_Grid
{
    internal class Core
    {
        /// <summary>
        ///Just returns whether or not a passed in object is null or an empty string
        ///</summary>
        ///<param name="o"></param>
        ///<returns></returns>
        ///<remarks></remarks>
        public static bool IsNullOrEmpty(object o)
        {
            if (o == null)
                return true;
            if (o == DBNull.Value)
                return true;
            if (o.GetType() == typeof(DataTable))
            {
                DataTable dtCheck = (DataTable)o;
                if (dtCheck.Rows.Count == 0 && dtCheck.Columns.Count == 0) return true;
                else return false;
            }
            else if (o.ToString().Trim() == "")
                return true;
            return false;
        }
    }
}